namespace GameControllerLib;

public interface IPlayer
{
	public int Id { get;}
	public string Name { get; }
}
