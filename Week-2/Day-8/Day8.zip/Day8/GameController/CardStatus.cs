namespace GameControllerLib;

public enum CardStatus
{
	OnDeck,
	OnPlayer,
	Removed
}
