﻿//Value Type
class Program {
	static void Main() {
		int a = 3;
		int b = a;
		
		b = 5;
		
		a.Dump();
		b.Dump();
	}
}