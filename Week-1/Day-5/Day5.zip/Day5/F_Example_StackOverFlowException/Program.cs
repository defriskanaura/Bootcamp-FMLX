﻿void Main()
{
	Run();
}
static void Run() {
	Run();
}
//StackOverFlowException