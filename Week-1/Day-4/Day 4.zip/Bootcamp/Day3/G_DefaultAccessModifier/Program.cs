﻿//Default Access Modifier

class Car { //internal
	string brand; // private
	
	private void EngineTest() { // private
	}
}