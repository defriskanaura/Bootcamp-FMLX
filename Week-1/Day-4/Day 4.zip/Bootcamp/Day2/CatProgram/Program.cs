﻿using Animal;
using Transportation;
class Program 
{
	static void Main() 
	{
		Cat cat = new Cat();
		cat.Sleep();
		Dog dog = new Dog();
		dog.Sleep();
	}
}