namespace CarComponent;

public class Door
{
	public string colour;
	public int quantity;
	public int size;
	public Door(string colour, int quantity, int size) 
	{
		this.colour = colour;
		this.quantity = quantity;
		this.size = size;
	}
}
