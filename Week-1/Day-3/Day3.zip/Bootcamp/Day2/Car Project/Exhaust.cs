namespace CarComponent;

public class Exhaust
{
	public string brand;
	public int size;
	public Exhaust(string brand, int size) 
	{
		this.brand = brand;
		this.size = size;
	}
}
