namespace Transportation;

public class Train
{
}
