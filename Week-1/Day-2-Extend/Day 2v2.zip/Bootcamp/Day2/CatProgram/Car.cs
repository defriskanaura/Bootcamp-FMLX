namespace Transportation;

public class Car
{
	public string brand;
	public int year;
}
