namespace Animal;

public class Dog
{
	public string colour;
	public int age;
	public bool isMale;
	public float weight;
	
	public void Eat() 
	{
		Console.WriteLine("Cat eat");
	}
	public void Sleep() 
	{
		Console.WriteLine("Dog Sleep");
	}
	public void Meow() 
	{
		Console.WriteLine("Meow");
	}
}
