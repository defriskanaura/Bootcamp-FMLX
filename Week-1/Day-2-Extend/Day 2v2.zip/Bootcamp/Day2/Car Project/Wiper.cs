namespace CarComponent;

public class Wiper
{
	public int speed;
	public Wiper(int speed) 
	{
		this.speed = speed;
	}
}
