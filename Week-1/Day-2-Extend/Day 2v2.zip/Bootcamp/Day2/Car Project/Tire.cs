namespace CarComponent;

public class Tire
{
	public int size;
	public string material;
	public Tire(int size, string material) 
	{
		this.size = size;
		this.material = material;
	}
}
