namespace CarComponent;

public class TransmisionOil
{
	public int volume;
	public TransmisionOil(int vol)
	{
		volume = vol;
	}
}
